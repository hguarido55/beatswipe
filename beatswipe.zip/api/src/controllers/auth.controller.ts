// api/src/controllers/auth.controller.ts

import { Request, Response } from 'express';
import * as AuthService from '../services/auth.service';

/**
 * POST /auth/register
 * Body: { email: string, password: string }
 */
export async function register(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email y password son requeridos' });
    }

    const user = await AuthService.register(email, password);
    // Devolver solo datos públicos del usuario
    return res.status(201).json({ id: user.id, email: user.email });
  } catch (error: any) {
    console.error('Error en register:', error);
    return res.status(400).json({ error: error.message || 'Error en registro' });
  }
}

/**
 * POST /auth/login
 * Body: { email: string, password: string }
 */
export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email y password son requeridos' });
    }

    const { token, user } = await AuthService.login(email, password);
    return res.json({ token, user });
  } catch (error: any) {
    console.error('Error en login:', error);
    return res.status(400).json({ error: error.message || 'Error en login' });
  }
}